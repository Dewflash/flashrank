#!/bin/zsh
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="$SCRIPT_DIR/app"
PORT_VALUE="${FLASHRANK_PORT:-3333}"

if ! command -v npm >/dev/null 2>&1; then
  osascript -e 'display dialog "FlashRank needs Node.js and npm installed. Install Node.js 20+ from https://nodejs.org, then run FlashRank.command again." buttons {"OK"} default button "OK" with icon caution' >/dev/null 2>&1 || true
  echo "FlashRank needs Node.js and npm installed. Install Node.js 20+ from https://nodejs.org."
  exit 1
fi

cd "$APP_DIR"

if [ ! -d node_modules ]; then
  echo "Installing dependencies..."
  npm install
fi

echo "Building FlashRank..."
npm run build

echo "Opening FlashRank at http://localhost:$PORT_VALUE"
( sleep 3; open "http://localhost:$PORT_VALUE" ) >/dev/null 2>&1 &

PORT="$PORT_VALUE" npm run start
